<?php
declare(strict_types=1);
if (!defined('PLEKSI_APP')) { http_response_code(404); exit; }
final class ApiError extends RuntimeException { public function __construct(string $message, public int $status = 400) { parent::__construct($message); } }
function fail(string $message, int $status=400): never { throw new ApiError($message,$status); }
function out(mixed $data,int $status=200): never { http_response_code($status);header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store');echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);exit; }
function enc(mixed $v): string { return json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR); }
function dec(string $v): mixed { return json_decode($v,true,512,JSON_THROW_ON_ERROR); }
function esc(mixed $v): string { return htmlspecialchars((string)$v,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8'); }
function sql(string $query,array $params=[]): PDOStatement { global $db; $s=$db->prepare($query);$s->execute($params);return $s; }
function one(string $query,array $params=[]): ?array { $r=sql($query,$params)->fetch();return $r===false?null:$r; }
function rows(string $query,array $params=[]): array { return sql($query,$params)->fetchAll(); }
function atomic(callable $fn): mixed { global $db;$db->beginTransaction();try{$result=$fn();$db->commit();return $result;}catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;} }
function now_ms(): int { return (int)floor(microtime(true)*1000); }
function phone(mixed $value): ?string { if(!is_string($value))return null;$n=preg_replace('/[\s()+-]/','',$value);if(str_starts_with($n,'0090'))$n=substr($n,2);if(strlen($n)===11&&$n[0]==='0')$n='90'.substr($n,1);if(strlen($n)===10)$n='90'.$n;return preg_match('/^905\d{9}$/D',$n)?$n:null; }
function valid_text(mixed $v,int $min=2,int $max=100): bool { return is_string($v)&&mb_strlen(trim($v),'UTF-8')>=$min&&mb_strlen($v,'UTF-8')<=$max; }
function money_value(mixed $v,float $min=0,float $max=1000000): bool { return (is_int($v)||is_float($v))&&is_finite((float)$v)&&$v>=$min&&$v<=$max&&abs($v*100-round($v*100))<0.00001; }
function setting(string $key,mixed $default=null): mixed { $r=one('SELECT value FROM ph_settings WHERE `key`=?',[$key]);return $r?$r['value']:$default; }
function set_setting(string $key,string $value): void { sql('INSERT INTO ph_settings (`key`,value) VALUES(?,?) ON DUPLICATE KEY UPDATE value=VALUES(value)',[$key,$value]); }
function delivery_options(): array { $fees=['pickup'=>0,'cargo'=>0,'address'=>0];$stored=setting('delivery_fees');if($stored)$fees=array_replace($fees,dec($stored));return array_map(fn($id,$label)=>['id'=>$id,'label'=>$label,'fee'=>(float)$fees[$id]],['pickup','cargo','address'],['Ortak Nokta / Elden Teslim','Kargo','Adrese Teslim']); }
function delivery(string $method): array { foreach(delivery_options() as $d)if($d['id']===$method)return $d;fail('Geçersiz teslimat seçeneği.'); }
function catalog_product(array $r): array {$p=dec($r['data']);$p['id']=(int)$r['id'];$p['commissionPercent']=(float)($p['commissionPercent']??20);$p['price']=(float)$p['price'];$p['dealerPrice']=round($p['price']*(100-$p['commissionPercent'])/100,2);$p['requireText']=(bool)($p['requireText']??false);$p['requireImage']=(bool)($p['requireImage']??false);return $p;}
function catalog(): array {return array_map('catalog_product',rows('SELECT id,data FROM ph_products ORDER BY id'));}
function product(int $id): ?array {$r=one('SELECT id,data FROM ph_products WHERE id=?',[$id]);return $r?catalog_product($r):null;}
function ensure_product_image_index(): bool {
 $locked=false;$lock='';$timeouts=null;
 try{
  if(setting('product_images_index_v1')==='ready')return true;
  if((int)setting('product_images_index_retry_after','0')>time())return false;
  set_setting('product_images_index_retry_after',(string)(time()+60));
  $lock='ph_images_'.substr(hash('sha256',(string)one('SELECT DATABASE() AS n')['n']),0,24);
  // An optional optimization must never hold up storefront, login or product requests.
  $locked=(int)one('SELECT GET_LOCK(?,0) AS acquired',[$lock])['acquired']===1;
  if(!$locked)return false;
  if(setting('product_images_index_v1')==='ready')return true;
  $timeouts=one('SELECT @@SESSION.lock_wait_timeout AS metadata_timeout,@@SESSION.innodb_lock_wait_timeout AS row_timeout');sql('SET SESSION lock_wait_timeout=1');sql('SET SESSION innodb_lock_wait_timeout=1');
  sql('CREATE TABLE IF NOT EXISTS ph_product_images (product_id BIGINT UNSIGNED NOT NULL,image_id CHAR(40) NOT NULL,PRIMARY KEY(product_id,image_id),INDEX image_lookup(image_id),FOREIGN KEY(product_id) REFERENCES ph_products(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
  atomic(function(){for($n=0;$n<3;$n++)sql("INSERT IGNORE INTO ph_product_images(product_id,image_id) SELECT id,JSON_UNQUOTE(JSON_EXTRACT(data,'$.images[$n]')) FROM ph_products WHERE JSON_UNQUOTE(JSON_EXTRACT(data,'$.images[$n]')) REGEXP '^[a-f0-9]{40}$'");set_setting('product_images_index_v1','ready');set_setting('product_images_index_retry_after','0');});return true;
 }catch(Throwable $e){error_log('Pleksi optional image index unavailable: '.$e::class);return false;}
 finally{if($timeouts)try{sql('SET SESSION lock_wait_timeout='.(int)$timeouts['metadata_timeout']);sql('SET SESSION innodb_lock_wait_timeout='.(int)$timeouts['row_timeout']);}catch(Throwable $ignored){}if($locked)try{one('SELECT RELEASE_LOCK(?)',[$lock]);}catch(Throwable $ignored){}}
}
function save_product(array $p,?string $xmlKey=null): array {global $db;if(!$db->inTransaction())return atomic(fn()=>save_product($p,$xmlKey));if(isset($p['id']))sql('UPDATE ph_products SET data=? WHERE id=?',[enc($p),$p['id']]);else{sql('INSERT INTO ph_products(data,xml_key) VALUES(?,?)',[enc($p),$xmlKey]);$p['id']=(int)$db->lastInsertId();sql('UPDATE ph_products SET data=? WHERE id=?',[enc($p),$p['id']]);}if($GLOBALS['product_image_index_ready']??false){sql('DELETE FROM ph_product_images WHERE product_id=?',[$p['id']]);foreach($p['images']??[] as $image)sql('INSERT INTO ph_product_images(product_id,image_id) VALUES(?,?)',[$p['id'],$image]);}return $p;}
function is_dealer(?array $u): bool {return ($u['dealer_status']??'')==='approved';}
function safe_user(?array $u): ?array {if(!$u)return null;return ['id'=>(int)$u['id'],'name'=>$u['name'],'firstName'=>$u['first_name'],'lastName'=>$u['last_name'],'phone'=>$u['phone'],'city'=>$u['city'],'district'=>$u['district'],'neighborhood'=>$u['neighborhood'],'role'=>$u['role'],'dealer_status'=>$u['dealer_status'],'mustChangePassword'=>(bool)$u['must_change_password']];}
function current_user(): ?array { $t=$_COOKIE['ph_session']??'';if(!preg_match('/^[a-f0-9]{64}$/D',$t))return null;$u=one('SELECT u.* FROM ph_users u JOIN ph_sessions s ON s.user_id=u.id WHERE s.token=? AND s.expires>?',[hash('sha256',$t),now_ms()]);if($u&&$u['role']!=='admin'&&!is_dealer($u)){sql('DELETE FROM ph_sessions WHERE user_id=?',[$u['id']]);return null;}return $u; }
function auth(): array {global $user;if(!$user)fail('Lütfen giriş yapın.',401);return $user;}
function admin(): array {$u=auth();if($u['role']!=='admin')fail('Yönetici yetkisi gerekiyor.',403);return $u;}
function request_is_https(): bool {return (!empty($_SERVER['HTTPS'])&&strtolower((string)$_SERVER['HTTPS'])!=='off')||(int)($_SERVER['SERVER_PORT']??0)===443;}
function new_session(int $id): void {global $config;$token=bin2hex(random_bytes(32));sql('INSERT INTO ph_sessions(token,user_id,expires) VALUES(?,?,?)',[hash('sha256',$token),$id,now_ms()+604800000]);setcookie('ph_session',$token,['expires'=>time()+604800,'path'=>($config['base_path']?:'').'/','secure'=>(bool)$config['secure_cookie'],'httponly'=>true,'samesite'=>'Lax']);}
function notify(string $type,int $id): void {sql('INSERT INTO ph_notifications(type,subject_id) VALUES(?,?)',[$type,$id]);}
function slug(array $p): string {$n=strtr($p['name'],['İ'=>'i','I'=>'i','ı'=>'i','Ğ'=>'g','ğ'=>'g','Ü'=>'u','ü'=>'u','Ş'=>'s','ş'=>'s','Ö'=>'o','ö'=>'o','Ç'=>'c','ç'=>'c']);$n=mb_strtolower($n,'UTF-8');$ascii=iconv('UTF-8','ASCII//TRANSLIT',$n);$n=preg_replace('/[^a-z0-9]+/','-',strtolower($ascii===false?$n:$ascii));return trim($n,'-').'-'.$p['id'];}
function seo_description(array $p): string { return mb_substr($p['name']." ile sevdiklerinize kişiye özel bir hediye hazırlayın. Yazı, renk ve görsel seçenekleriyle Pleksi Hediye'de keşfedin.",0,160,'UTF-8'); }
function image_mime(string $bytes): string { $i=@getimagesizefromstring($bytes);$mime=$i['mime']??'';if(!in_array($mime,['image/jpeg','image/png','image/webp'],true)||$i[0]*$i[1]>40000000)fail('Geçerli bir JPG, PNG veya WebP seçin (en fazla 40 megapiksel).');return $mime; }
function upload_save(string $bytes,int $uid): string {if(strlen($bytes)>5*1024*1024)fail('Görsel en fazla 5 MB olabilir.');$mime=image_mime($bytes);$id=bin2hex(random_bytes(20));sql('INSERT INTO ph_uploads(id,user_id,mime,data) VALUES(?,?,?,?)',[$id,$uid,$mime,$bytes]);return $id;}
function send_image(string $id): never {global $user;$image=one('SELECT * FROM ph_uploads WHERE id=?',[$id]);if(!$image)fail('Görsel bulunamadı.',404);$home=homepage_content();$public=setting('store_logo')===$id||$home['heroImageId']===$id||$home['storyImageId']===$id;if(!$public&&($GLOBALS['product_image_index_ready']??false))$public=(bool)one("SELECT pi.product_id FROM ph_product_images pi JOIN ph_products p ON p.id=pi.product_id WHERE pi.image_id=? AND COALESCE(JSON_UNQUOTE(JSON_EXTRACT(p.data,'$.active')),'true')<>'false' AND JSON_CONTAINS(JSON_EXTRACT(p.data,'$.images'),JSON_QUOTE(?)) LIMIT 1",[$id,$id]);if(!$public)$public=(bool)one("SELECT id FROM ph_products WHERE COALESCE(JSON_UNQUOTE(JSON_EXTRACT(data,'$.active')),'true')<>'false' AND JSON_CONTAINS(JSON_EXTRACT(data,'$.images'),JSON_QUOTE(?)) LIMIT 1",[$id]);$allowed=$public||($user&&($user['role']==='admin'||(int)$image['user_id']===(int)$user['id']));if(!$allowed&&$user){foreach(rows('SELECT items FROM ph_orders WHERE user_id=? AND deleted_at IS NULL',[$user['id']]) as $o)foreach(dec($o['items']) as $i)if(($i['artwork']??null)===$id){$allowed=true;break 2;}}if(!$allowed)fail('Görsele erişim yetkiniz yok.',403);header('Content-Type: '.$image['mime']);header('Cache-Control: '.($public?'public, max-age=3600':'private, no-store'));echo $image['data'];exit; }
